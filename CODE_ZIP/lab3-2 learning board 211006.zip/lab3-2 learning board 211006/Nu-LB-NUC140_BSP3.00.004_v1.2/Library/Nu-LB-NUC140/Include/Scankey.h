#ifndef SCANKEY_H
#define SCANKEY_H

void OpenKeyPad(void);
void CloseKeyPad(void);
uint8_t ScanKey(void);

#endif

